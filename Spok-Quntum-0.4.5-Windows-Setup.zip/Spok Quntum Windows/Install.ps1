$ErrorActionPreference = "Stop"
$source = Join-Path $PSScriptRoot "Spok Quntum.vst3"
$destRoot = Join-Path $env:ProgramFiles "Common Files\VST3"
$dest = Join-Path $destRoot "Spok Quntum.vst3"
if (-not (Test-Path -LiteralPath $source)) { throw "Bundle not found next to Install.ps1" }
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    $arg = "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    Start-Process -FilePath "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -ArgumentList $arg -Verb RunAs
    exit 0
}
New-Item -ItemType Directory -Force -Path $destRoot | Out-Null
if (Test-Path -LiteralPath $dest) { Remove-Item -LiteralPath $dest -Recurse -Force }
Copy-Item -LiteralPath $source -Destination $dest -Recurse -Force
Get-ChildItem -LiteralPath $dest -Recurse -File | Unblock-File -ErrorAction SilentlyContinue
$dll = Join-Path $dest "Contents\x86_64-win\Spok Quntum.vst3"
if (-not (Test-Path -LiteralPath $dll)) { throw "Installed bundle has no Windows binary" }
$redist = Join-Path $PSScriptRoot "vc_redist.x64.exe"
if (Test-Path -LiteralPath $redist) {
    $proc = Start-Process -FilePath $redist -ArgumentList "/install","/quiet","/norestart" -Wait -PassThru
    if ($proc.ExitCode -ne 0 -and $proc.ExitCode -ne 1638 -and $proc.ExitCode -ne 3010) {
        throw "Visual C++ runtime installer failed with exit $($proc.ExitCode)"
    }
}
Write-Host "Installed: $dest"
Write-Host "In Ableton: Preferences, Plug-ins, Use VST3 Plug-In System Folders, then Rescan."
